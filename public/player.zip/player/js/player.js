var soundFile = null,
pauseTime = 0,
audioTime = 0,
startTime = 0,
dispTime = 0;
playing = false,
pausing = false,
repeatFlag = false,
listNum = 0,
list = ["bgm/"],
audioName = [""],
volumeControl = null;

window.addEventListener("DOMContentLoaded", function() {
  title = document.querySelector("#title");
  volume = document.querySelector("#volume");
  play = document.querySelector("#play");
  pause = document.querySelector("#pause");
  // 初期状態ではポーズボタンを非表示
  pause.style.display="none";
  stop = document.querySelector("#stop");
  timeBar = document.querySelector("#timeBar");
  cTime = document.querySelector("#currentTime");
  mTime = document.querySelector("#maxTime");
  repeatBtn = document.querySelector("#repeatBtn");
  inputFile = document.querySelector('#input');
},false
);
